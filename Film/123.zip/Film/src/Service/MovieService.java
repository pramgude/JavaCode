package Service;

import java.util.List;

import Entity.Movie;

public interface MovieService {
	List<String> getTitle();
	

	
}
