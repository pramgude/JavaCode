

var arr =[3,4,57,81]
var res = arr.map(function(e){
  return  e*2
})

console.log(res)


var res1 = arr.map(e=>e*2)
console.log(res1)



