import React,{Component} from 'react'
class CoursesPage extends Component{
    render(){
        return (
            <h2>All Courses</h2>
        )
    }

}
export default CoursesPage