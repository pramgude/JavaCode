import React from "react";



const PageNotFound=()=>(
    <h1>Page Not Found!!!!</h1>
)
export default PageNotFound