package Entity;

public class TicketBook {
	int TicketId;
	String TheatreName;
	
	public TicketBook(int TicketId,String TheatreName) {
		this.TicketId=TicketId;
		this.TheatreName=TheatreName;
	}

}
